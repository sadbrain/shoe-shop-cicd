import React from 'react'
import ProductGrid from '../components/product/ProductList'

function Shop() {
  return (
    <ProductGrid />
    )
}

export default Shop