export const variables = {
    BASE_URL: "http://devenv.mixcredevops.vip:5214/api/",
    USER_API: "http://devenv.mixcredevops.vip:5214/api/user",
    PRODUCT_API: "http://devenv.mixcredevops.vip:5214/api/product",
    ORDER_API: "http://devenv.mixcredevops.vip:5214/api/order",
    PRODUCTSIZE_API: "http://devenv.mixcredevops.vip:5214/api/productsize",
    ORDERITEM_API: "http://devenv.mixcredevops.vip:5214/api/orderitem",
}